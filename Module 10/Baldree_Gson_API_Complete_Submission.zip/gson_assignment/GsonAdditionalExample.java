import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.List;

public class GsonAdditionalExample {

    static class CourseScore {
        String name;
        String course;
        int score;

        CourseScore() {
            // Gson can use this empty constructor when building objects from JSON.
        }

        CourseScore(String name, String course, int score) {
            this.name = name;
            this.course = course;
            this.score = score;
        }
    }

    public static void main(String[] args) {
        String json = """
                [
                  {"name":"Alex", "course":"CSD420", "score":95},
                  {"name":"Jordan", "course":"CSD420", "score":88},
                  {"name":"Taylor", "course":"CSD420", "score":91}
                ]
                """;

        Gson gson = new GsonBuilder()
                .setPrettyPrinting()
                .create();

        Type listType = new TypeToken<List<CourseScore>>() {}.getType();
        List<CourseScore> scores = gson.fromJson(json, listType);

        System.out.println("Parsed JSON data:");
        for (CourseScore score : scores) {
            System.out.println(score.name + " earned " + score.score + " in " + score.course);
        }

        CourseScore newScore = new CourseScore("Morgan", "CSD420", 93);
        scores.add(newScore);

        String updatedJson = gson.toJson(scores);
        System.out.println("\nUpdated JSON output:");
        System.out.println(updatedJson);
    }
}
