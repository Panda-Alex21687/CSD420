How to run GsonAdditionalExample.java

1. Download gson-2.14.0.jar from Maven Central.
2. Place gson-2.14.0.jar in the same folder as GsonAdditionalExample.java.
3. Compile and run:

Mac/Linux:
javac -cp "gson-2.14.0.jar" GsonAdditionalExample.java
java -cp ".:gson-2.14.0.jar" GsonAdditionalExample

Windows:
javac -cp "gson-2.14.0.jar" GsonAdditionalExample.java
java -cp ".;gson-2.14.0.jar" GsonAdditionalExample

This example parses a JSON array into Java objects, prints the data, adds one new object, and serializes the updated list back to formatted JSON.
